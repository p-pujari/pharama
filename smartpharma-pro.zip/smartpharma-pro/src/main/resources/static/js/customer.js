
// ==========================================
// SMARTPHARMA PRO - CUSTOMER MARKETPLACE
// File: js/customer.js
// ==========================================


// Sample medicine catalogue
// This will later be replaced by backend API data.

const medicines = [
    {
        id: 1,
        name: "Paracetamol 500mg",
        category: "Pain Relief",
        barcode: "890123450001",
        price: 25,
        stock: 250,
        store: "City Care Pharmacy",
        description: "Used for relief from pain and fever."
    },
    {
        id: 2,
        name: "Vitamin C 500mg",
        category: "Vitamins",
        barcode: "890123450002",
        price: 60,
        stock: 80,
        store: "Health Plus Medicals",
        description: "Vitamin C supplement."
    },
    {
        id: 3,
        name: "Cetirizine 10mg",
        category: "Healthcare",
        barcode: "890123450003",
        price: 35,
        stock: 75,
        store: "Wellness Medical Store",
        description: "Antihistamine medicine."
    },
    {
        id: 4,
        name: "Ibuprofen 200mg",
        category: "Pain Relief",
        barcode: "890123450004",
        price: 45,
        stock: 100,
        store: "City Care Pharmacy",
        description: "Pain and inflammation relief."
    },
    {
        id: 5,
        name: "Multivitamin Tablets",
        category: "Vitamins",
        barcode: "890123450005",
        price: 120,
        stock: 50,
        store: "Health Plus Medicals",
        description: "Daily multivitamin supplement."
    },
    {
        id: 6,
        name: "Antiseptic Cream",
        category: "Healthcare",
        barcode: "890123450006",
        price: 55,
        stock: 40,
        store: "Wellness Medical Store",
        description: "For minor skin care needs."
    }
];


// Selected pharmacy
let selectedStore = "All";


// Current category
let selectedCategory = "All";


// Get cart from browser storage
function getCart() {
    try {
        const cart = JSON.parse(localStorage.getItem("smartpharmaCart"));
        return Array.isArray(cart) ? cart : [];
    } catch (error) {
        return [];
    }
}


// Save cart
function saveCart(cart) {
    localStorage.setItem("smartpharmaCart", JSON.stringify(cart));
}


// Display medicine cards
function displayMedicines(list) {

    const container = document.getElementById("medicineContainer");
    const noMedicines = document.getElementById("noMedicines");

    if (!container) return;

    container.innerHTML = "";

    if (list.length === 0) {
        if (noMedicines) {
            noMedicines.style.display = "block";
        }
        return;
    }

    if (noMedicines) {
        noMedicines.style.display = "none";
    }

    list.forEach(medicine => {

        const card = document.createElement("div");
        card.className = "col-md-4 col-lg-4";

        card.innerHTML = `
            <div class="medicine-card">

                <div class="medicine-icon">
                    <i class="bi bi-capsule"></i>
                </div>

                <h5 class="medicine-name">
                    ${medicine.name}
                </h5>

                <p class="muted mb-1">
                    ${medicine.description}
                </p>

                <p class="muted mb-1">
                    Category: ${medicine.category}
                </p>

                <p class="muted mb-1">
                    Pharmacy: ${medicine.store}
                </p>

                <p class="muted mb-3">
                    Stock: ${medicine.stock}
                </p>

                <div class="d-flex justify-content-between
                            align-items-center">

                    <span class="price">
                        ₹${medicine.price}
                    </span>

                    <button class="btn btn-green"
                            onclick="addToCart(${medicine.id})"
                            ${medicine.stock <= 0 ? "disabled" : ""}>
                        <i class="bi bi-cart-plus"></i>
                        Add
                    </button>

                </div>

            </div>
        `;

        container.appendChild(card);
    });
}


// Search medicines
function searchMedicines() {

    const searchInput = document.getElementById("searchInput");

    if (!searchInput) return;

    const searchValue = searchInput.value.trim().toLowerCase();

    const filteredMedicines = medicines.filter(medicine => {

        const matchesSearch =
            medicine.name.toLowerCase().includes(searchValue) ||
            medicine.barcode.toLowerCase().includes(searchValue);

        const matchesCategory =
            selectedCategory === "All" ||
            medicine.category === selectedCategory;

        const matchesStore =
            selectedStore === "All" ||
            medicine.store === selectedStore;

        return matchesSearch && matchesCategory && matchesStore;
    });

    displayMedicines(filteredMedicines);
}


// Filter medicine category
function filterCategory(category, element) {

    selectedCategory = category;

    document.querySelectorAll(".category").forEach(item => {
        item.classList.remove("active");
    });

    if (element) {
        element.classList.add("active");
    }

    searchMedicines();
}


// Select pharmacy store
function selectStore(storeName) {

    selectedStore = storeName;

    selectedCategory = "All";

    document.querySelectorAll(".category").forEach(item => {
        item.classList.remove("active");
    });

    const allCategory = document.querySelector(".category");

    if (allCategory) {
        allCategory.classList.add("active");
    }

    const medicineSection = document.getElementById("medicines");

    if (medicineSection) {
        medicineSection.scrollIntoView({
            behavior: "smooth"
        });
    }

    searchMedicines();

    alert("Showing medicines from " + storeName);
}


// Add medicine to cart
function addToCart(medicineId) {

    const medicine = medicines.find(item => item.id === medicineId);

    if (!medicine) {
        alert("Medicine not found.");
        return;
    }

    if (medicine.stock <= 0) {
        alert("This medicine is currently out of stock.");
        return;
    }

    const cart = getCart();

    // Include store in the cart identity so
    // the same medicine from different stores stays separate.
    const existingItem = cart.find(item =>
        item.id === medicine.id &&
        item.store === medicine.store
    );

    if (existingItem) {

        if (existingItem.quantity >= medicine.stock) {
            alert("Available stock limit reached.");
            return;
        }

        existingItem.quantity++;

    } else {

        cart.push({
            id: medicine.id,
            name: medicine.name,
            price: medicine.price,
            quantity: 1,
            store: medicine.store,
            barcode: medicine.barcode
        });
    }

    saveCart(cart);

    updateCartCount();

    alert(medicine.name + " added to your cart!");
}


// Update cart count
function updateCartCount() {

    const cart = getCart();

    const totalItems = cart.reduce((total, item) => {
        return total + Number(item.quantity || 0);
    }, 0);

    const cartCount = document.getElementById("cartCount");

    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}


// Initial page loading
document.addEventListener("DOMContentLoaded", function () {

    displayMedicines(medicines);

    updateCartCount();

    const searchInput = document.getElementById("searchInput");

    if (searchInput) {
        searchInput.addEventListener("input", searchMedicines);

        searchInput.addEventListener("keydown", function(event) {
            if (event.key === "Enter") {
                searchMedicines();
            }
        });
    }

});
