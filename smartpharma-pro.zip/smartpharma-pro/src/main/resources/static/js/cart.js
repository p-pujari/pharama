
// ==========================================
// SMARTPHARMA PRO - SHOPPING CART
// File: js/cart.js
// ==========================================

const CART_KEY = "smartpharmaCart";
const ORDER_KEY = "smartpharmaOrders";

const DELIVERY_CHARGE = 40;
const FREE_DELIVERY_LIMIT = 500;


// Get cart data
function getCart() {
    try {
        const cart = JSON.parse(localStorage.getItem(CART_KEY));
        return Array.isArray(cart) ? cart : [];
    } catch (error) {
        return [];
    }
}


// Save cart data
function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}


// Update navbar cart count
function updateCartCount() {
    const cart = getCart();

    const totalItems = cart.reduce((total, item) => {
        return total + Number(item.quantity || 0);
    }, 0);

    const cartCount = document.getElementById("cartCount");

    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}


// Format currency
function formatCurrency(amount) {
    return "₹" + Number(amount).toFixed(2);
}


// Calculate subtotal
function calculateSubtotal(cart) {
    return cart.reduce((total, item) => {
        return total +
            (Number(item.price) * Number(item.quantity));
    }, 0);
}


// Display cart items
function displayCart() {

    const cart = getCart();

    const cartItems = document.getElementById("cartItems");
    const emptyCart = document.getElementById("emptyCart");
    const itemCount = document.getElementById("itemCount");

    if (!cartItems) return;

    cartItems.innerHTML = "";

    if (cart.length === 0) {

        cartItems.style.display = "none";
        emptyCart.style.display = "block";

        itemCount.textContent = "0 items";

        updateSummary(cart);
        updateCartCount();

        return;
    }

    cartItems.style.display = "block";
    emptyCart.style.display = "none";

    let totalQuantity = 0;

    cart.forEach((item, index) => {

        const quantity = Number(item.quantity) || 1;
        const price = Number(item.price) || 0;

        totalQuantity += quantity;

        const itemTotal = price * quantity;

        const itemElement = document.createElement("div");

        itemElement.className =
            "d-flex flex-column flex-md-row align-items-md-center " +
            "justify-content-between gap-3 border-bottom pb-4 mb-4";

        const icon = document.createElement("div");
        icon.className = "medicine-icon flex-shrink-0";
        icon.innerHTML = '<i class="bi bi-capsule"></i>';

        const details = document.createElement("div");
        details.className = "flex-grow-1";

        const name = document.createElement("h6");
        name.className = "medicine-name mb-1";
        name.textContent = item.name;

        const store = document.createElement("p");
        store.className = "muted mb-1";
        store.textContent = "Pharmacy: " + (item.store || "Not specified");

        const unitPrice = document.createElement("p");
        unitPrice.className = "muted mb-0";
        unitPrice.textContent = "Unit price: " + formatCurrency(price);

        details.append(name, store, unitPrice);

        const quantityControl = document.createElement("div");
        quantityControl.className = "quantity-control";

        const decreaseButton = document.createElement("button");
        decreaseButton.type = "button";
        decreaseButton.textContent = "−";
        decreaseButton.setAttribute("aria-label", "Decrease quantity");
        decreaseButton.addEventListener("click", () => {
            updateQuantity(index, -1);
        });

        const quantityText = document.createElement("strong");
        quantityText.textContent = quantity;

        const increaseButton = document.createElement("button");
        increaseButton.type = "button";
        increaseButton.textContent = "+";
        increaseButton.setAttribute("aria-label", "Increase quantity");
        increaseButton.addEventListener("click", () => {
            updateQuantity(index, 1);
        });

        quantityControl.append(
            decreaseButton,
            quantityText,
            increaseButton
        );

        const amount = document.createElement("div");
        amount.className = "text-md-end";

        const amountText = document.createElement("strong");
        amountText.className = "price d-block";
        amountText.textContent = formatCurrency(itemTotal);

        const removeButton = document.createElement("button");
        removeButton.type = "button";
        removeButton.className = "btn btn-link text-danger p-0 small";
        removeButton.textContent = "Remove";
        removeButton.addEventListener("click", () => {
            removeItem(index);
        });

        amount.append(amountText, removeButton);

        itemElement.append(
            icon,
            details,
            quantityControl,
            amount
        );

        cartItems.appendChild(itemElement);
    });

    itemCount.textContent =
        totalQuantity + (totalQuantity === 1 ? " item" : " items");

    updateSummary(cart);
    updateCartCount();
}


// Update quantity
function updateQuantity(index, change) {

    const cart = getCart();

    if (!cart[index]) return;

    const newQuantity =
        Number(cart[index].quantity) + change;

    if (newQuantity <= 0) {
        removeItem(index);
        return;
    }

    cart[index].quantity = newQuantity;

    saveCart(cart);
    displayCart();
}


// Remove medicine from cart
function removeItem(index) {

    const cart = getCart();

    if (!cart[index]) return;

    const confirmed = confirm(
        "Are you sure you want to remove this medicine?"
    );

    if (!confirmed) return;

    cart.splice(index, 1);

    saveCart(cart);
    displayCart();
}


// Update order summary
function updateSummary(cart) {

    const subtotal = calculateSubtotal(cart);

    const deliveryCharge =
        subtotal === 0 || subtotal >= FREE_DELIVERY_LIMIT
            ? 0
            : DELIVERY_CHARGE;

    const discount = 0;

    const grandTotal =
        subtotal + deliveryCharge - discount;

    document.getElementById("subtotal").textContent =
        formatCurrency(subtotal);

    document.getElementById("deliveryCharge").textContent =
        formatCurrency(deliveryCharge);

    document.getElementById("discount").textContent =
        formatCurrency(discount);

    document.getElementById("grandTotal").textContent =
        formatCurrency(grandTotal);

    const checkoutButton =
        document.getElementById("checkoutButton");

    if (checkoutButton) {
        checkoutButton.disabled = cart.length === 0;
    }
}


// Validate delivery details
function validateDeliveryDetails() {

    const name =
        document.getElementById("customerName").value.trim();

    const phone =
        document.getElementById("customerPhone").value.trim();

    const address =
        document.getElementById("deliveryAddress").value.trim();

    const instructions =
        document.getElementById("deliveryInstructions").value.trim();

    if (!name) {
        alert("Please enter your full name.");
        return null;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
        alert("Please enter a valid 10-digit Indian mobile number.");
        return null;
    }

    if (address.length < 10) {
        alert("Please enter your complete delivery address.");
        return null;
    }

    return {
        name: name,
        phone: phone,
        address: address,
        instructions: instructions
    };
}


// Proceed to checkout
function proceedToCheckout() {

    const cart = getCart();

    if (cart.length === 0) {
        alert("Your cart is empty.");
        return;
    }

    // Prevent mixing medicines from different pharmacies
    const stores = [
        ...new Set(cart.map(item => item.store))
    ];

    if (stores.length > 1) {
        alert(
            "Your cart contains medicines from multiple pharmacies. " +
            "Please place separate orders for each pharmacy."
        );
        return;
    }

    const customer = validateDeliveryDetails();

    if (!customer) return;

    const subtotal = calculateSubtotal(cart);

    const deliveryCharge =
        subtotal >= FREE_DELIVERY_LIMIT ? 0 : DELIVERY_CHARGE;

    const order = {
        orderId: "SP" + Date.now(),
        items: cart,
        customer: customer,
        store: stores[0],
        subtotal: subtotal,
        deliveryCharge: deliveryCharge,
        discount: 0,
        total: subtotal + deliveryCharge,
        status: "Pending",
        paymentStatus: "Not Paid",
        paymentMethod: null,
        createdAt: new Date().toISOString()
    };

    try {
        const existingOrders = JSON.parse(
            localStorage.getItem(ORDER_KEY) || "[]"
        );

        if (!Array.isArray(existingOrders)) {
            throw new Error("Invalid order data");
        }

        existingOrders.push(order);

        localStorage.setItem(
            ORDER_KEY,
            JSON.stringify(existingOrders)
        );

        // Preserve the cart until checkout is completed.
        sessionStorage.setItem(
            "smartpharmaCheckoutOrder",
            JSON.stringify(order)
        );

        window.location.href = "checkout.html";

    } catch (error) {
        console.error("Unable to save order:", error);
        alert("Unable to continue. Please try again.");
    }
}


// Load cart page
document.addEventListener("DOMContentLoaded", function() {
    displayCart();
});
