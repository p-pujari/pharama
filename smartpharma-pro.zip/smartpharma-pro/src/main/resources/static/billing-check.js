(() => {
    "use strict";

    const medicineOptions = [...document.querySelectorAll(".medicine-option")];
    const cartItems = document.getElementById("cartItems");
    const searchInput = document.getElementById("medicineSearch");
    const discountInput = document.getElementById("discount");
    const cart = new Map();

    const money = amount =>
        "₹" + amount.toFixed(2);

    // Search by medicine name or barcode.
    searchInput.addEventListener("input", () => {
        const query = searchInput.value.trim().toLowerCase();
        let matchCount = 0;

        medicineOptions.forEach(option => {
            const name = option.dataset.name.toLowerCase();
            const barcode = option.dataset.barcode;

            const matches = name.includes(query) || barcode.includes(query);

            option.classList.toggle("d-none", !matches);

            if (matches) {
                matchCount++;
            }
        });

        document.getElementById("noMedicines")
            .classList.toggle("d-none", matchCount !== 0);
    });

    // Add a medicine to the cart.
    medicineOptions.forEach(option => {
        const addButton = option.querySelector(".add-to-cart");

        addButton.addEventListener("click", () => {
            const name = option.dataset.name;
            const stock = Number(option.dataset.stock);
            const existingItem = cart.get(name);

            if (existingItem && existingItem.quantity >= stock) {
                alert("Cannot add more than the available demo stock.");
                return;
            }

            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.set(name, {
                    name: name,
                    barcode: option.dataset.barcode,
                    price: Number(option.dataset.price),
                    stock: stock,
                    quantity: 1
                });
            }

            renderCart();
        });
    });

    // Render the current cart.
    function renderCart() {
        cartItems.replaceChildren();

        if (cart.size === 0) {
            const emptyMessage = document.createElement("div");
            emptyMessage.className = "text-center text-secondary py-4";

            const icon = document.createElement("i");
            icon.className = "bi bi-cart-x fs-2 d-block mb-2";

            const message = document.createTextNode(
                "Your cart is empty. Add a medicine to begin."
            );

            emptyMessage.append(icon, message);
            cartItems.appendChild(emptyMessage);
        }

        cart.forEach(item => {
            const line = document.createElement("div");
            line.className = "cart-line";

            const name = document.createElement("strong");
            name.textContent = item.name;

            const price = document.createElement("small");
            price.className = "d-block text-secondary";
            price.textContent = `${money(item.price)} each`;

            const controls = document.createElement("div");
            controls.className = "d-flex align-items-center gap-2 mt-2";

            const minus = document.createElement("button");
            minus.type = "button";
            minus.className = "btn btn-sm btn-outline-secondary";
            minus.textContent = "−";
            minus.setAttribute("aria-label", `Decrease ${item.name} quantity`);

            minus.addEventListener("click", () => {
                item.quantity--;

                if (item.quantity <= 0) {
                    cart.delete(item.name);
                }

                renderCart();
            });

            const quantity = document.createElement("span");
            quantity.textContent = item.quantity;

            const plus = document.createElement("button");
            plus.type = "button";
            plus.className = "btn btn-sm btn-outline-secondary";
            plus.textContent = "+";
            plus.setAttribute("aria-label", `Increase ${item.name} quantity`);

            plus.addEventListener("click", () => {
                if (item.quantity >= item.stock) {
                    alert("Cannot exceed available demo stock.");
                    return;
                }

                item.quantity++;
                renderCart();
            });

            const lineTotal = document.createElement("strong");
            lineTotal.className = "ms-auto";
            lineTotal.textContent = money(item.price * item.quantity);

            controls.append(minus, quantity, plus, lineTotal);
            line.append(name, price, controls);
            cartItems.appendChild(line);
        });

        calculateTotal();
    }

    // Calculate subtotal, discount, demo tax, and grand total.
    function calculateTotal() {
        const subtotal = [...cart.values()].reduce(
            (sum, item) => sum + item.price * item.quantity,
            0
        );

        const discountPercent = Math.min(
            100,
            Math.max(0, Number(discountInput.value) || 0)
        );

        const discount = subtotal * discountPercent / 100;
        const taxableAmount = subtotal - discount;
        const tax = taxableAmount * 0.05;
        const total = taxableAmount + tax;

        document.getElementById("subtotal").textContent = money(subtotal);
        document.getElementById("discountAmount").textContent = money(discount);
        document.getElementById("taxAmount").textContent = money(tax);
        document.getElementById("grandTotal").textContent = money(total);

        return { subtotal, discount, tax, total };
    }

    discountInput.addEventListener("input", calculateTotal);

    // Clear the cart.
    document.getElementById("clearCart").addEventListener("click", () => {
        cart.clear();
        renderCart();
    });

    // Generate a demo receipt.
    document.getElementById("checkoutBtn").addEventListener("click", () => {
        if (cart.size === 0) {
            alert("Please add at least one medicine before completing the sale.");
            return;
        }

        const totals = calculateTotal();

        const customer =
            document.getElementById("customerName").value.trim()
            || "Walk-in Customer";

        const phone =
            document.getElementById("customerPhone").value.trim()
            || "Not provided";

        const payment = document.getElementById("paymentMethod").value;
        const receiptContent = document.getElementById("receiptContent");

        receiptContent.replaceChildren();

        const heading = document.createElement("h5");
        heading.textContent = "SmartPharma Pro";
        receiptContent.appendChild(heading);

        const customerLine = document.createElement("p");
        customerLine.textContent = `Customer: ${customer} | Phone: ${phone}`;
        receiptContent.appendChild(customerLine);

        const paymentLine = document.createElement("p");
        paymentLine.textContent = `Payment method: ${payment}`;
        receiptContent.appendChild(paymentLine);

        const list = document.createElement("ul");

        cart.forEach(item => {
            const listItem = document.createElement("li");
            listItem.textContent =
                `${item.name} × ${item.quantity} — ${money(item.price * item.quantity)}`;

            list.appendChild(listItem);
        });

        receiptContent.appendChild(list);

        const subtotalLine = document.createElement("p");
        subtotalLine.textContent = `Subtotal: ${money(totals.subtotal)}`;
        receiptContent.appendChild(subtotalLine);

        const discountLine = document.createElement("p");
        discountLine.textContent = `Discount: ${money(totals.discount)}`;
        receiptContent.appendChild(discountLine);

        const taxLine = document.createElement("p");
        taxLine.textContent = `Demo tax (5%): ${money(totals.tax)}`;
        receiptContent.appendChild(taxLine);

        const totalLine = document.createElement("h5");
        totalLine.textContent = `Grand Total: ${money(totals.total)}`;
        receiptContent.appendChild(totalLine);

        const note = document.createElement("p");
        note.className = "text-secondary small";
        note.textContent =
            "Demo receipt only. No payment was processed and no sale was saved to the database.";
        receiptContent.appendChild(note);

        bootstrap.Modal
            .getOrCreateInstance(document.getElementById("receiptModal"))
            .show();
    });

    // Print the receipt.
    document.getElementById("printReceipt").addEventListener("click", () => {
        const content = document.getElementById("receiptContent").innerHTML;
        const printWindow = window.open("", "_blank", "width=600,height=700");

        if (!printWindow) {
            alert("Please allow pop-ups to print the receipt.");
            return;
        }

        printWindow.document.write(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>SmartPharma Pro Receipt</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 24px;
                        color: #222;
                    }
                    h5 {
                        margin-bottom: 16px;
                    }
                    li {
                        margin-bottom: 8px;
                    }
                    @media print {
                        body { padding: 0; }
                    }
                </style>
            </head>
            <body>${content}</body>
            </html>
        `);

        printWindow.document.close();
        printWindow.focus();

        printWindow.onload = () => {
            printWindow.print();
        };
    });

    // Show correct initial totals.
    calculateTotal();
})();