
package com.smartpharma.service;

import com.smartpharma.entity.Medicine;
import com.smartpharma.entity.Sale;
import com.smartpharma.entity.SaleItem;
import com.smartpharma.repository.MedicineRepository;
import com.smartpharma.repository.SaleItemRepository;
import com.smartpharma.repository.SaleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

@Service
public class SaleService {

    private final SaleRepository saleRepository;
    private final SaleItemRepository saleItemRepository;
    private final MedicineRepository medicineRepository;

    public SaleService(
            SaleRepository saleRepository,
            SaleItemRepository saleItemRepository,
            MedicineRepository medicineRepository) {
        this.saleRepository = saleRepository;
        this.saleItemRepository = saleItemRepository;
        this.medicineRepository = medicineRepository;
    }

    public List<Sale> getAllSales() {
        return saleRepository.findAllByOrderByCreatedAtDesc();
    }

    public Sale getSaleById(Long id) {
        return saleRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException("Sale not found: " + id));
    }

    @Transactional
    public Sale createCashSale(
            String customerName,
            String customerPhone,
            BigDecimal discountPercent,
            List<SaleRequestItem> requestedItems) {

        if (requestedItems == null || requestedItems.isEmpty()) {
            throw new IllegalArgumentException(
                    "A sale must contain at least one medicine.");
        }

        if (discountPercent == null
                || discountPercent.compareTo(BigDecimal.ZERO) < 0
                || discountPercent.compareTo(new BigDecimal("100")) > 0) {
            throw new IllegalArgumentException(
                    "Discount must be between 0 and 100 percent.");
        }

        // Step 1: Validate quantities and combine duplicate medicine IDs.
        Map<Long, Integer> totalQuantityByMedicine = new HashMap<>();

        for (SaleRequestItem request : requestedItems) {
            if (request == null || request.medicineId() == null) {
                throw new IllegalArgumentException(
                        "Every item must include a medicine ID.");
            }

            if (request.quantity() == null || request.quantity() <= 0) {
                throw new IllegalArgumentException(
                        "Medicine quantity must be greater than zero.");
            }

            try {
                totalQuantityByMedicine.merge(
                        request.medicineId(),
                        request.quantity(),
                        Math::addExact
                );
            } catch (ArithmeticException exception) {
                throw new IllegalArgumentException(
                        "Total medicine quantity is too large.");
            }
        }

        // Step 2: Lock medicine rows in a consistent ID order.
        // This reduces the risk of deadlocks during simultaneous sales.
        Map<Long, Medicine> lockedMedicines = new HashMap<>();

        TreeSet<Long> sortedMedicineIds =
                new TreeSet<>(totalQuantityByMedicine.keySet());

        for (Long medicineId : sortedMedicineIds) {
            Medicine medicine = medicineRepository
                    .findByIdForUpdate(medicineId)
                    .orElseThrow(() -> new IllegalArgumentException(
                            "Medicine not found: " + medicineId));

            lockedMedicines.put(medicineId, medicine);
        }

        // Step 3: Validate every medicine before changing any stock.
        for (Map.Entry<Long, Integer> entry
                : totalQuantityByMedicine.entrySet()) {

            Medicine medicine = lockedMedicines.get(entry.getKey());
            int requestedQuantity = entry.getValue();

            if (!medicine.isActive()) {
                throw new IllegalArgumentException(
                        medicine.getName() + " is inactive.");
            }

            if (medicine.getExpiryDate() == null
                    || medicine.getExpiryDate().isBefore(LocalDate.now())) {
                throw new IllegalArgumentException(
                        medicine.getName()
                                + " is expired or has no expiry date.");
            }

            if (medicine.getStockQuantity() == null
                    || medicine.getStockQuantity() < requestedQuantity) {
                throw new IllegalArgumentException(
                        "Insufficient stock for " + medicine.getName()
                                + ". Available: "
                                + medicine.getStockQuantity()
                                + ", requested: " + requestedQuantity);
            }

            if (medicine.getPrice() == null
                    || medicine.getPrice().compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException(
                        "Invalid price for " + medicine.getName());
            }
        }

        // Step 4: Prepare the sale and its line items.
        Sale sale = new Sale();
        sale.setCustomerName(clean(customerName));
        sale.setCustomerPhone(clean(customerPhone));
        sale.setPaymentMethod("CASH");
        sale.setPaymentStatus("PAID");
        sale.setDiscountPercent(
                discountPercent.setScale(2, RoundingMode.HALF_UP));

        BigDecimal subtotal = BigDecimal.ZERO;
        List<SaleItem> items = new ArrayList<>();

        for (SaleRequestItem request : requestedItems) {
            Medicine medicine = lockedMedicines.get(request.medicineId());

            BigDecimal unitPrice = medicine.getPrice()
                    .setScale(2, RoundingMode.HALF_UP);

            BigDecimal lineTotal = unitPrice
                    .multiply(BigDecimal.valueOf(request.quantity()))
                    .setScale(2, RoundingMode.HALF_UP);

            subtotal = subtotal.add(lineTotal);

            SaleItem item = new SaleItem();
            item.setSale(sale);
            item.setMedicine(medicine);
            item.setQuantity(request.quantity());
            item.setUnitPrice(unitPrice);
            item.setLineTotal(lineTotal);

            items.add(item);
        }

        subtotal = subtotal.setScale(2, RoundingMode.HALF_UP);

        BigDecimal discountAmount = subtotal
                .multiply(sale.getDiscountPercent())
                .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);

        BigDecimal grandTotal = subtotal.subtract(discountAmount)
                .setScale(2, RoundingMode.HALF_UP);

        sale.setSubtotal(subtotal);
        sale.setDiscountAmount(discountAmount);
        sale.setTaxAmount(BigDecimal.ZERO.setScale(2));
        sale.setGrandTotal(grandTotal);

        // Step 5: Deduct stock only after all medicines have passed validation.
        for (Map.Entry<Long, Integer> entry
                : totalQuantityByMedicine.entrySet()) {

            Medicine medicine = lockedMedicines.get(entry.getKey());

            medicine.setStockQuantity(
                    medicine.getStockQuantity() - entry.getValue());
        }

        // Step 6: Save the sale and its items within the same transaction.
        Sale savedSale = saleRepository.save(sale);
        saleItemRepository.saveAll(items);

        return savedSale;
    }

    private String clean(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    public record SaleRequestItem(Long medicineId, Integer quantity) {
    }
}
