
package com.smartpharma.service;

import com.smartpharma.entity.Medicine;
import com.smartpharma.repository.MedicineRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class MedicineService {

    private final MedicineRepository medicineRepository;

    public MedicineService(MedicineRepository medicineRepository) {
        this.medicineRepository = medicineRepository;
    }

    // Get all medicines
    public List<Medicine> getAllMedicines() {
        return medicineRepository.findAll();
    }

    // Get one medicine by ID
    public Optional<Medicine> getMedicineById(Long id) {
        return medicineRepository.findById(id);
    }

    // Search by medicine name
    public List<Medicine> searchMedicines(String name) {
        if (name == null || name.isBlank()) {
            return getAllMedicines();
        }

        return medicineRepository
                .findByNameContainingIgnoreCase(name.trim());
    }

    // Search by barcode
    public Optional<Medicine> getMedicineByBarcode(String barcode) {
        if (barcode == null || barcode.isBlank()) {
            return Optional.empty();
        }

        return medicineRepository.findByBarcode(barcode.trim());
    }

    // Validate medicine data before saving
    private void validateMedicine(Medicine medicine, Long currentId) {
        if (medicine == null) {
            throw new IllegalArgumentException(
                    "Medicine details are required.");
        }

        if (medicine.getName() == null
                || medicine.getName().isBlank()) {
            throw new IllegalArgumentException(
                    "Medicine name is required.");
        }

        if (medicine.getBatchNumber() == null
                || medicine.getBatchNumber().isBlank()) {
            throw new IllegalArgumentException(
                    "Batch number is required.");
        }

        if (medicine.getPrice() == null
                || medicine.getPrice().signum() <= 0) {
            throw new IllegalArgumentException(
                    "Medicine price must be greater than zero.");
        }

        if (medicine.getStockQuantity() == null
                || medicine.getStockQuantity() < 0) {
            throw new IllegalArgumentException(
                    "Stock quantity cannot be negative.");
        }

        if (medicine.getMinimumStockLevel() == null
                || medicine.getMinimumStockLevel() < 0) {
            throw new IllegalArgumentException(
                    "Minimum stock level cannot be negative.");
        }

        if (medicine.getExpiryDate() == null
                || !medicine.getExpiryDate().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException(
                    "Expiry date must be in the future.");
        }

        // Barcode is optional, but if supplied it must be unique.
        String barcode = medicine.getBarcode();

        if (barcode != null && !barcode.isBlank()) {
            barcode = barcode.trim();
            medicine.setBarcode(barcode);

            Optional<Medicine> existingBarcode =
                    medicineRepository.findByBarcode(barcode);

            if (existingBarcode.isPresent()
                    && !existingBarcode.get().getId().equals(currentId)) {
                throw new IllegalArgumentException(
                        "This barcode is already assigned to another medicine.");
            }
        } else {
            medicine.setBarcode(null);
        }
    }

    // Add a medicine
    @Transactional
    public Medicine addMedicine(Medicine medicine) {
        medicine.setId(null);
        validateMedicine(medicine, null);
        return medicineRepository.save(medicine);
    }

    // Update an existing medicine
    @Transactional
    public Medicine updateMedicine(Long id, Medicine updatedMedicine) {
        Medicine existing = medicineRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Medicine not found: " + id));

        validateMedicine(updatedMedicine, id);

        existing.setName(updatedMedicine.getName().trim());
        existing.setGenericName(updatedMedicine.getGenericName());
        existing.setManufacturer(updatedMedicine.getManufacturer());
        existing.setBarcode(updatedMedicine.getBarcode());
        existing.setBatchNumber(updatedMedicine.getBatchNumber().trim());
        existing.setPrice(updatedMedicine.getPrice());
        existing.setStockQuantity(updatedMedicine.getStockQuantity());
        existing.setMinimumStockLevel(
                updatedMedicine.getMinimumStockLevel());
        existing.setExpiryDate(updatedMedicine.getExpiryDate());
        existing.setAisle(updatedMedicine.getAisle());
        existing.setRack(updatedMedicine.getRack());
        existing.setShelf(updatedMedicine.getShelf());
        existing.setBinLocation(updatedMedicine.getBinLocation());
        existing.setActive(updatedMedicine.isActive());

        return medicineRepository.save(existing);
    }

    // Find medicines that need restocking
    public List<Medicine> getLowStockMedicines() {
        return medicineRepository.findAll().stream()
                .filter(medicine ->
                        medicine.isActive()
                        && medicine.getStockQuantity() != null
                        && medicine.getMinimumStockLevel() != null
                        && medicine.getStockQuantity()
                                <= medicine.getMinimumStockLevel())
                .toList();
    }

    // Deactivate a medicine instead of permanently deleting its record
    @Transactional
    public void deactivateMedicine(Long id) {
        Medicine medicine = medicineRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Medicine not found: " + id));

        medicine.setActive(false);
        medicineRepository.save(medicine);
    }
}
