package com.smartpharma.service;

public class SponsorService {
    
}
