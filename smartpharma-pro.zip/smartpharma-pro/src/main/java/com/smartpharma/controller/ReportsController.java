
package com.smartpharma.controller;

import com.smartpharma.entity.Medicine;
import com.smartpharma.entity.Sale;
import com.smartpharma.entity.SaleItem;
import com.smartpharma.repository.MedicineRepository;
import com.smartpharma.repository.SaleItemRepository;
import com.smartpharma.repository.SaleRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/reports")
public class ReportsController {

    private final SaleRepository saleRepository;
    private final SaleItemRepository saleItemRepository;
    private final MedicineRepository medicineRepository;

    public ReportsController(
            SaleRepository saleRepository,
            SaleItemRepository saleItemRepository,
            MedicineRepository medicineRepository) {
        this.saleRepository = saleRepository;
        this.saleItemRepository = saleItemRepository;
        this.medicineRepository = medicineRepository;
    }

    @GetMapping("/summary")
    @Transactional(readOnly = true)
    public Map<String, Object> getSummary() {
        LocalDate today = LocalDate.now();

        List<Sale> paidSales = saleRepository.findAll().stream()
                .filter(this::isPaid)
                .toList();

        BigDecimal totalRevenue = sumSales(paidSales);

        BigDecimal todayRevenue = sumSales(
                paidSales.stream()
                        .filter(s -> s.getCreatedAt() != null
                                && s.getCreatedAt().toLocalDate().equals(today))
                        .toList());

        List<Medicine> medicines = medicineRepository.findAll();

        long lowStockCount = medicines.stream()
                .filter(Medicine::isActive)
                .filter(m -> m.getStockQuantity() != null
                        && m.getMinimumStockLevel() != null
                        && m.getStockQuantity() <= m.getMinimumStockLevel())
                .count();

        long expiredCount = medicines.stream()
                .filter(Medicine::isActive)
                .filter(m -> m.getExpiryDate() != null
                        && m.getExpiryDate().isBefore(today))
                .count();

        long expiringSoonCount = medicines.stream()
                .filter(Medicine::isActive)
                .filter(m -> m.getExpiryDate() != null
                        && !m.getExpiryDate().isBefore(today)
                        && !m.getExpiryDate().isAfter(today.plusDays(90)))
                .count();

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("totalSales", totalRevenue);
        result.put("totalOrders", paidSales.size());

        result.put("averageOrderValue",
                paidSales.isEmpty()
                        ? BigDecimal.ZERO
                        : totalRevenue.divide(
                                BigDecimal.valueOf(paidSales.size()),
                                2,
                                RoundingMode.HALF_UP));

        result.put("todaySales", todayRevenue);

        result.put("todayOrders",
                paidSales.stream()
                        .filter(s -> s.getCreatedAt() != null
                                && s.getCreatedAt().toLocalDate().equals(today))
                        .count());

        result.put("inventoryAlerts", lowStockCount);
        result.put("expiredMedicines", expiredCount);
        result.put("expiringSoon", expiringSoonCount);
        result.put("currency", "INR");

        return result;
    }

    @GetMapping("/sales-trend")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getSalesTrend(
            @RequestParam(defaultValue = "7") int days) {

        int safeDays = Math.max(1, Math.min(days, 90));

        LocalDate today = LocalDate.now();
        LocalDate startDate = today.minusDays(safeDays - 1L);

        List<Sale> sales =
                saleRepository.findByCreatedAtBetweenOrderByCreatedAtDesc(
                        startDate.atStartOfDay(),
                        today.plusDays(1).atStartOfDay());

        Map<LocalDate, BigDecimal> totals = new LinkedHashMap<>();

        for (int i = 0; i < safeDays; i++) {
            totals.put(startDate.plusDays(i), BigDecimal.ZERO);
        }

        for (Sale sale : sales) {
            if (isPaid(sale) && sale.getCreatedAt() != null) {
                LocalDate date = sale.getCreatedAt().toLocalDate();

                if (totals.containsKey(date)) {
                    totals.put(
                            date,
                            totals.get(date).add(sale.getGrandTotal()));
                }
            }
        }

        List<Map<String, Object>> result = new ArrayList<>();

        totals.forEach((date, amount) -> {
            Map<String, Object> point = new LinkedHashMap<>();
            point.put("date", date.toString());
            point.put("sales", amount);
            result.add(point);
        });

        return result;
    }

    @GetMapping("/low-stock")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getLowStock() {
        LocalDate today = LocalDate.now();

        return medicineRepository.findAll().stream()
                .filter(Medicine::isActive)
                .filter(m -> m.getStockQuantity() != null
                        && m.getMinimumStockLevel() != null
                        && m.getStockQuantity() <= m.getMinimumStockLevel())
                .filter(m -> m.getExpiryDate() != null
                        && !m.getExpiryDate().isBefore(today))
                .sorted(Comparator.comparing(Medicine::getStockQuantity))
                .map(m -> medicineRow(m, "stock"))
                .toList();
    }

    @GetMapping("/expiry")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getExpiryMonitoring() {
        LocalDate today = LocalDate.now();

        return medicineRepository.findAll().stream()
                .filter(Medicine::isActive)
                .filter(m -> m.getExpiryDate() != null)
                .filter(m -> !m.getExpiryDate().isAfter(today.plusDays(90)))
                .sorted(Comparator.comparing(Medicine::getExpiryDate))
                .map(m -> medicineRow(m, "expiry"))
                .toList();
    }

    @GetMapping("/top-selling")
    @Transactional(readOnly = true)
    public List<Map<String, Object>> getTopSelling() {
        Map<Long, Map<String, Object>> products = new LinkedHashMap<>();

        for (Sale sale : saleRepository.findAll()) {
            if (!isPaid(sale)) {
                continue;
            }

            List<SaleItem> items =
                    saleItemRepository.findBySaleId(sale.getId());

            for (SaleItem item : items) {
                Medicine medicine = item.getMedicine();

                if (medicine == null || medicine.getId() == null) {
                    continue;
                }

                Long medicineId = medicine.getId();

                Map<String, Object> row = products.computeIfAbsent(
                        medicineId,
                        id -> {
                            Map<String, Object> product =
                                    new LinkedHashMap<>();

                            product.put("medicineId", id);
                            product.put("name", medicine.getName());
                            product.put("unitsSold", 0);
                            product.put("revenue", BigDecimal.ZERO);

                            return product;
                        });

                int currentUnits = (Integer) row.get("unitsSold");
                row.put(
                        "unitsSold",
                        currentUnits + item.getQuantity());

                BigDecimal currentRevenue =
                        (BigDecimal) row.get("revenue");

                row.put(
                        "revenue",
                        currentRevenue.add(item.getLineTotal()));
            }
        }

        return products.values().stream()
                .sorted((a, b) -> Integer.compare(
                        (Integer) b.get("unitsSold"),
                        (Integer) a.get("unitsSold")))
                .limit(10)
                .collect(Collectors.toList());
    }

    private boolean isPaid(Sale sale) {
        return sale.getPaymentStatus() != null
                && "PAID".equalsIgnoreCase(sale.getPaymentStatus())
                && sale.getGrandTotal() != null;
    }

    private BigDecimal sumSales(List<Sale> sales) {
        return sales.stream()
                .map(Sale::getGrandTotal)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private Map<String, Object> medicineRow(
            Medicine medicine,
            String type) {

        Map<String, Object> row = new LinkedHashMap<>();

        row.put("id", medicine.getId());
        row.put("name", medicine.getName());
        row.put("stockQuantity", medicine.getStockQuantity());
        row.put("minimumStockLevel", medicine.getMinimumStockLevel());

        row.put(
                "expiryDate",
                medicine.getExpiryDate() == null
                        ? null
                        : medicine.getExpiryDate().toString());

        row.put("price", medicine.getPrice());

        row.put(
                "status",
                type.equals("stock")
                        ? "LOW STOCK"
                        : medicine.getExpiryDate() != null
                                && medicine.getExpiryDate()
                                        .isBefore(LocalDate.now())
                                ? "EXPIRED"
                                : "EXPIRING SOON");

        return row;
    }
}
