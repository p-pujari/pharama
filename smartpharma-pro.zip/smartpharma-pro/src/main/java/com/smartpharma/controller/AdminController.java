package com.smartpharma.controller;

public class AdminController {
    
}
