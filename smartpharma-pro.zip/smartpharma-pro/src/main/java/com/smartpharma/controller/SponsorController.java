package com.smartpharma.controller;

public class SponsorController {
    
}
