
package com.smartpharma.controller;

import com.smartpharma.entity.Sale;
import com.smartpharma.service.SaleService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sales")
public class SaleController {

    private final SaleService saleService;

    public SaleController(SaleService saleService) {
        this.saleService = saleService;
    }

    @GetMapping
    public ResponseEntity<List<Sale>> getAllSales() {
        return ResponseEntity.ok(saleService.getAllSales());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getSaleById(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(saleService.getSaleById(id));
        } catch (IllegalArgumentException exception) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", exception.getMessage()));
        }
    }

    @PostMapping
    public ResponseEntity<?> createCashSale(
            @RequestBody(required = false) CreateSaleRequest request) {

        try {
            if (request == null) {
                throw new IllegalArgumentException(
                        "Sale request is required."
                );
            }

            if (request.paymentMethod() == null
                    || !request.paymentMethod().equalsIgnoreCase("CASH")) {
                return ResponseEntity.badRequest().body(
                        Map.of(
                                "message",
                                "Only cash checkout is currently supported. "
                                + "Online payments are not yet integrated."
                        )
                );
            }

            SaleService.SaleRequestItem[] items = request.items();

            if (items == null || items.length == 0) {
                throw new IllegalArgumentException(
                        "At least one sale item is required."
                );
            }

            BigDecimal discountPercent =
                    request.discountPercent() == null
                            ? BigDecimal.ZERO
                            : request.discountPercent();

            Sale sale = saleService.createCashSale(
                    request.customerName(),
                    request.customerPhone(),
                    discountPercent,
                    List.of(items)
            );

            return ResponseEntity.status(HttpStatus.CREATED).body(
                    Map.ofEntries(
                            Map.entry("id", sale.getId()),
                            Map.entry(
                                    "customerName",
                                    sale.getCustomerName() == null
                                            ? "" : sale.getCustomerName()
                            ),
                            Map.entry(
                                    "customerPhone",
                                    sale.getCustomerPhone() == null
                                            ? "" : sale.getCustomerPhone()
                            ),
                            Map.entry(
                                    "paymentMethod",
                                    sale.getPaymentMethod()
                            ),
                            Map.entry(
                                    "paymentStatus",
                                    sale.getPaymentStatus()
                            ),
                            Map.entry("subtotal", sale.getSubtotal()),
                            Map.entry(
                                    "discountPercent",
                                    sale.getDiscountPercent()
                            ),
                            Map.entry(
                                    "discountAmount",
                                    sale.getDiscountAmount()
                            ),
                            Map.entry("taxAmount", sale.getTaxAmount()),
                            Map.entry("grandTotal", sale.getGrandTotal()),
                            Map.entry("createdAt", sale.getCreatedAt())
                    )
            );

        } catch (IllegalArgumentException exception) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", exception.getMessage())
            );
        }
    }

    public record CreateSaleRequest(
            String customerName,
            String customerPhone,
            String paymentMethod,
            BigDecimal discountPercent,
            SaleService.SaleRequestItem[] items
    ) {
    }
}
