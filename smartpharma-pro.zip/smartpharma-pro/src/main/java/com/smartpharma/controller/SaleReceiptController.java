
package com.smartpharma.controller;

import com.smartpharma.entity.Sale;
import com.smartpharma.entity.SaleItem;
import com.smartpharma.repository.SaleItemRepository;
import com.smartpharma.repository.SaleRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/sales")
public class SaleReceiptController {

    private final SaleRepository saleRepository;
    private final SaleItemRepository saleItemRepository;

    public SaleReceiptController(
            SaleRepository saleRepository,
            SaleItemRepository saleItemRepository) {
        this.saleRepository = saleRepository;
        this.saleItemRepository = saleItemRepository;
    }

    @GetMapping("/{id}/receipt")
    public ResponseEntity<?> getReceipt(@PathVariable Long id) {
        Sale sale = saleRepository.findById(id).orElse(null);

        if (sale == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Sale not found."));
        }

        List<Map<String, Object>> items = saleItemRepository
                .findBySaleId(id)
                .stream()
                .map(this::toItemResponse)
                .toList();

        Map<String, Object> receipt = new LinkedHashMap<>();
        receipt.put("id", sale.getId());
        receipt.put("customerName", sale.getCustomerName());
        receipt.put("customerPhone", sale.getCustomerPhone());
        receipt.put("paymentMethod", sale.getPaymentMethod());
        receipt.put("paymentStatus", sale.getPaymentStatus());
        receipt.put("subtotal", sale.getSubtotal());
        receipt.put("discountPercent", sale.getDiscountPercent());
        receipt.put("discountAmount", sale.getDiscountAmount());
        receipt.put("taxAmount", sale.getTaxAmount());
        receipt.put("grandTotal", sale.getGrandTotal());
        receipt.put("createdAt", sale.getCreatedAt());
        receipt.put("items", items);

        return ResponseEntity.ok(receipt);
    }

    private Map<String, Object> toItemResponse(SaleItem item) {
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("medicineId", item.getMedicine().getId());
        result.put("medicineName", item.getMedicine().getName());
        result.put("quantity", item.getQuantity());
        result.put("unitPrice", item.getUnitPrice());
        result.put("lineTotal", item.getLineTotal());
        return result;
    }
}
