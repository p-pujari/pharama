
package com.smartpharma.controller;

import com.smartpharma.entity.Medicine;
import com.smartpharma.service.MedicineService;

import jakarta.validation.Valid;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/medicines")
@CrossOrigin(origins = "*")
public class MedicineController {

    private final MedicineService medicineService;

    public MedicineController(MedicineService medicineService) {
        this.medicineService = medicineService;
    }

    // Get all medicines, or search by name
    @GetMapping
    public List<Medicine> getMedicines(
            @RequestParam(required = false) String search) {

        if (search != null && !search.isBlank()) {
            return medicineService.searchMedicines(search);
        }

        return medicineService.getAllMedicines();
    }

    // Get medicine by ID
    @GetMapping("/{id}")
    public ResponseEntity<Medicine> getMedicineById(
            @PathVariable Long id) {

        return medicineService.getMedicineById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Find medicine by barcode
    @GetMapping("/barcode/{barcode}")
    public ResponseEntity<Medicine> getMedicineByBarcode(
            @PathVariable String barcode) {

        return medicineService.getMedicineByBarcode(barcode)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get low-stock medicines
    @GetMapping("/low-stock")
    public List<Medicine> getLowStockMedicines() {
        return medicineService.getLowStockMedicines();
    }

    // Add a new medicine
    @PostMapping
    public ResponseEntity<Medicine> addMedicine(
            @Valid @RequestBody Medicine medicine) {

        Medicine savedMedicine = medicineService.addMedicine(medicine);

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(savedMedicine);
    }

    // Update an existing medicine
    @PutMapping("/{id}")
    public ResponseEntity<?> updateMedicine(
            @PathVariable Long id,
            @Valid @RequestBody Medicine medicine) {

        try {
            return ResponseEntity.ok(
                    medicineService.updateMedicine(id, medicine));

        } catch (IllegalArgumentException exception) {
            if (exception.getMessage() != null
                    && exception.getMessage().startsWith("Medicine not found:")) {
                return errorResponse(
                        HttpStatus.NOT_FOUND, exception.getMessage());
            }

            return errorResponse(
                    HttpStatus.BAD_REQUEST, exception.getMessage());
        }
    }

    // Deactivate a medicine
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deactivateMedicine(
            @PathVariable Long id) {

        try {
            medicineService.deactivateMedicine(id);
            return ResponseEntity.noContent().build();

        } catch (IllegalArgumentException exception) {
            return errorResponse(
                    HttpStatus.NOT_FOUND, exception.getMessage());
        }
    }

    // Handle invalid fields such as missing name or invalid price
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationErrors(
            MethodArgumentNotValidException exception) {

        Map<String, Object> response = new LinkedHashMap<>();
        Map<String, String> fieldErrors = new LinkedHashMap<>();

        exception.getBindingResult().getFieldErrors().forEach(error ->
                fieldErrors.putIfAbsent(
                        error.getField(),
                        error.getDefaultMessage()));

        response.put("status", HttpStatus.BAD_REQUEST.value());
        response.put("error", "Validation failed");
        response.put("messages", fieldErrors);

        return ResponseEntity.badRequest().body(response);
    }

    // Handle business validation errors
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleInvalidArguments(
            IllegalArgumentException exception) {

        return errorResponse(
                HttpStatus.BAD_REQUEST, exception.getMessage());
    }

    // Handle duplicate barcodes or other database constraint violations
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, Object>> handleDatabaseErrors(
            DataIntegrityViolationException exception) {

        return errorResponse(
                HttpStatus.CONFLICT,
                "The medicine could not be saved because of a duplicate "
                        + "barcode or another database constraint.");
    }

    private ResponseEntity<Map<String, Object>> errorResponse(
            HttpStatus status, String message) {

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("status", status.value());
        response.put("error", status.getReasonPhrase());
        response.put("message",
                message == null ? "The request could not be completed." : message);

        return ResponseEntity.status(status).body(response);
    }
}
