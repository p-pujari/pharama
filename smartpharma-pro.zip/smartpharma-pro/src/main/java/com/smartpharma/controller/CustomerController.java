package com.smartpharma.controller;

import com.smartpharma.entity.Customer;
import com.smartpharma.repository.CustomerRepository;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerRepository customerRepository;

    public CustomerController(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getCustomerById(@PathVariable Long id) {
        return customerRepository.findById(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("message", "Customer not found")));
    }

    @PostMapping
    public ResponseEntity<?> addCustomer(
            @Valid @RequestBody Customer customer,
            BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message",
                            bindingResult.getFieldErrors().get(0).getDefaultMessage())
            );
        }

        customer.setId(null);
        customer.setName(customer.getName().trim());
        customer.setPhone(customer.getPhone().trim());

        if (customer.getEmail() != null) {
            customer.setEmail(customer.getEmail().trim());
            if (customer.getEmail().isEmpty()) {
                customer.setEmail(null);
            }
        }

        if (customerRepository.existsByPhone(customer.getPhone())) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "A customer with this phone number already exists")
            );
        }

        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(customerRepository.save(customer));
        } catch (DataIntegrityViolationException exception) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Could not save customer. Check for duplicate details.")
            );
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateCustomer(
            @PathVariable Long id,
            @Valid @RequestBody Customer updatedCustomer,
            BindingResult bindingResult) {

        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().body(
                    Map.of("message",
                            bindingResult.getFieldErrors().get(0).getDefaultMessage())
            );
        }

        Customer existing = customerRepository.findById(id).orElse(null);

        if (existing == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Customer not found"));
        }

        String phone = updatedCustomer.getPhone().trim();

        boolean phoneUsedByAnotherCustomer =
                customerRepository.findByPhone(phone)
                        .filter(customer -> !customer.getId().equals(id))
                        .isPresent();

        if (phoneUsedByAnotherCustomer) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Another customer already uses this phone number")
            );
        }

        existing.setName(updatedCustomer.getName().trim());
        existing.setPhone(phone);
        existing.setEmail(
                updatedCustomer.getEmail() == null
                        || updatedCustomer.getEmail().trim().isEmpty()
                        ? null
                        : updatedCustomer.getEmail().trim()
        );
        existing.setPrescriptionRecorded(
                updatedCustomer.isPrescriptionRecorded()
        );

        try {
            return ResponseEntity.ok(customerRepository.save(existing));
        } catch (DataIntegrityViolationException exception) {
            return ResponseEntity.badRequest().body(
                    Map.of("message", "Could not update customer details")
            );
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteCustomer(@PathVariable Long id) {
        if (!customerRepository.existsById(id)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Customer not found"));
        }

        customerRepository.deleteById(id);

        return ResponseEntity.ok(
                Map.of("message", "Customer deleted successfully")
        );
    }
}