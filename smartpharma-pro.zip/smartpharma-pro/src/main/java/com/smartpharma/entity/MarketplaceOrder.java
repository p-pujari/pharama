package com.smartpharma.entity;

public class MarketplaceOrder {
    
}
