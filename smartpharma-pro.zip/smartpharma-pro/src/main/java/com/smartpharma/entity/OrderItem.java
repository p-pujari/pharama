package com.smartpharma.entity;

public class OrderItem {
    
}
