package com.smartpharma.entity;

public class Sponsor {
    
}
