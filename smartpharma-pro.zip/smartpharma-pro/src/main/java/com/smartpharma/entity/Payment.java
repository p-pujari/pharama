package com.smartpharma.entity;

public class Payment {
    
}
