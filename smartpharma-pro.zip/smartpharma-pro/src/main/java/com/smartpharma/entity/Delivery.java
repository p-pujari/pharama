package com.smartpharma.entity;

public class Delivery {
    
}
