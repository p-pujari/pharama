package com.smartpharma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartpharmaProApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartpharmaProApplication.class, args);
	}

}
