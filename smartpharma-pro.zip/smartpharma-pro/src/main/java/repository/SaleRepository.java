
package com.smartpharma.repository;

import com.smartpharma.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface SaleRepository extends JpaRepository<Sale, Long> {

    List<Sale> findAllByOrderByCreatedAtDesc();

    List<Sale> findByCreatedAtBetweenOrderByCreatedAtDesc(
            LocalDateTime startDate,
            LocalDateTime endDate
    );

    List<Sale> findByPaymentStatusOrderByCreatedAtDesc(
            String paymentStatus
    );
}
