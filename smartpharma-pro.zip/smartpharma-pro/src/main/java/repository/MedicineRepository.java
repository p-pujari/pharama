
package com.smartpharma.repository;

import com.smartpharma.entity.Medicine;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface MedicineRepository extends JpaRepository<Medicine, Long> {

    // Search medicines by name
    List<Medicine> findByNameContainingIgnoreCase(String name);

    // Find a medicine using its barcode
    Optional<Medicine> findByBarcode(String barcode);

    // Find medicines using their batch number
    List<Medicine> findByBatchNumber(String batchNumber);

    // Find medicines that need restocking
    List<Medicine> findByStockQuantityLessThanEqual(Integer quantity);

    // Find medicines by active status
    List<Medicine> findByActive(boolean active);

    // Lock a medicine row while processing a sale
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT m FROM Medicine m WHERE m.id = :id")
    Optional<Medicine> findByIdForUpdate(@Param("id") Long id);
}
