package repository;

public class SponsorRepository {
    
}
