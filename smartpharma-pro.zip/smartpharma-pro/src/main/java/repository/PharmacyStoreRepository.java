package repository;

public class PharmacyStoreRepository {
    
}
