
package com.smartpharma.service;

import com.smartpharma.entity.Medicine;
import com.smartpharma.repository.MedicineRepository;
import com.smartpharma.repository.SaleItemRepository;
import com.smartpharma.repository.SaleRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SaleServiceTest {

    @Mock
    private SaleRepository saleRepository;

    @Mock
    private SaleItemRepository saleItemRepository;

    @Mock
    private MedicineRepository medicineRepository;

    @InjectMocks
    private SaleService saleService;

    private Medicine medicine;

    @BeforeEach
    void setUp() {
        medicine = new Medicine();

        medicine.setId(1L);
        medicine.setName("Test Paracetamol");
        medicine.setBatchNumber("TEST-BATCH-001");
        medicine.setPrice(new BigDecimal("25.00"));
        medicine.setStockQuantity(5);
        medicine.setMinimumStockLevel(1);
        medicine.setExpiryDate(LocalDate.now().plusMonths(6));
        medicine.setActive(true);
    }

    @Test
    void rejectsSaleWhenRequestedQuantityExceedsStock() {

        when(medicineRepository.findByIdForUpdate(1L))
                .thenReturn(Optional.of(medicine));

        SaleService.SaleRequestItem item =
                new SaleService.SaleRequestItem(1L, 6);

        assertThrows(
                IllegalArgumentException.class,
                () -> saleService.createCashSale(
                        "Test Customer",
                        null,
                        BigDecimal.ZERO,
                        List.of(item)
                )
        );

        verify(medicineRepository).findByIdForUpdate(1L);
        verify(saleRepository, never()).save(any());
        verify(saleItemRepository, never()).saveAll(any());

        assertEquals(5, medicine.getStockQuantity());
    }

    @Test
    void rejectsExpiredMedicine() {

        medicine.setExpiryDate(LocalDate.now().minusDays(1));

        when(medicineRepository.findByIdForUpdate(1L))
                .thenReturn(Optional.of(medicine));

        SaleService.SaleRequestItem item =
                new SaleService.SaleRequestItem(1L, 1);

        assertThrows(
                IllegalArgumentException.class,
                () -> saleService.createCashSale(
                        "Test Customer",
                        null,
                        BigDecimal.ZERO,
                        List.of(item)
                )
        );

        verify(saleRepository, never()).save(any());
        verify(saleItemRepository, never()).saveAll(any());

        assertEquals(5, medicine.getStockQuantity());
    }

    @Test
    void rejectsInactiveMedicine() {

        medicine.setActive(false);

        when(medicineRepository.findByIdForUpdate(1L))
                .thenReturn(Optional.of(medicine));

        SaleService.SaleRequestItem item =
                new SaleService.SaleRequestItem(1L, 1);

        assertThrows(
                IllegalArgumentException.class,
                () -> saleService.createCashSale(
                        "Test Customer",
                        null,
                        BigDecimal.ZERO,
                        List.of(item)
                )
        );

        verify(saleRepository, never()).save(any());
        verify(saleItemRepository, never()).saveAll(any());

        assertEquals(5, medicine.getStockQuantity());
    }
}
